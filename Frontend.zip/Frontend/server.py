import json
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

alljobs = [
    {
        "title": "M6.C Industrial Economics",
        "instructor": "Kal Huschelrath",
        "location": 'en',
        'insertion_date': time.time(),
        "description": "Introduction\n\nPart I - Basic Models\nBasic Market Models\nOligopoly I: Basic Models\nOligopoly II: Address Models\nOligopoly III: Evidence\n\nPartII - Conduct\nCollusion\nDominant Firms\nPrice Discrimination\n\nPart III - Organization/Market Structure\nFirm and Firm Structure\nMergers\nInterfirm Contracts\n\nPart IV - Applications\nAdvertising, Information, and Sales\nInnovation/Promoting Innovation"
    },
    {
        "title": "VDI2206- Development of Mechatronic Systems",
        "instructor": "Prof. Dr. S. Roth",
        "location": 'en',
        'insertion_date': time.time(),
        "description": "N.N"
    },
    {
        "title": "M4.E Purchasing Strategy",
        "instructor": "Prof Dr Michael Dornieden",
        "location": 'en',
        'insertion_date': time.time(),
        "description": "1. Importance, functions and objectives of procurement management\n2. Original Equipment Manufacturer and Original Equipment Supplier\n3. Classification of supplying products\n4. Sourcing strategies\n4.1. Strategic levers\n4.2. Outsourcing\n4.3. Cost analysis\n4.4. Reversed Sourcing\n4.5. Forward Sourcing\n4.6. Electronic procurement\n4.7. Value Engineering"
    },
    {
        "title": "Automation Control",
        "instructor": "Prof. Dr. Bachmann",
        "location": 'en',
        'insertion_date': time.time(),
        "description": "Today, complex automation solutions are highly automated systems that produce the highest quality with maximum performance. The focal points in their realization are: Conception of communication and networking, decentralized system design, selection of suitable techniques and technologies for implementation, design of a heterogeneous structure, control engineering mastery of complex, non-linear system structures, robot integration, statistical process analysis"
    }
]

class SimpleRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # Récupérer les paramètres de la requête
        query_components = parse_qs(urlparse(self.path).query)

        title_filter = query_components.get("title", [""])[0].lower()
        location_filter = query_components.get("location", [""])[0].lower()
        page_size = int(query_components.get("page_size", [10])[0])
        page = int(query_components.get("page", [1])[0])

        if (title_filter) :
            time.sleep(20)  # Attente de 20 secondes

        # Filtrer les jobs en fonction des paramètres
        filtered_jobs = []
        for job in alljobs:
            if (title_filter in job["title"].lower() or 
                # location_filter in job["location"].lower() or
                title_filter in job["instructor"].lower() or
                title_filter in job["description"].lower()
                ):
                filtered_jobs.append(job)

        # Pagination
        start_index = (page - 1) * page_size
        end_index = start_index + page_size
        paginated_jobs = filtered_jobs[start_index:end_index]

        response = {
            "total_jobs": len(filtered_jobs),
            "jobs": paginated_jobs
        }

        # Envoi de la réponse
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*') 
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')  
        self.send_header('Access-Control-Allow-Headers', 'Content-Type') 
        self.end_headers()

        self.wfile.write(json.dumps(response).encode('utf-8'))

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*') 
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS') 
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Access-Control-Max-Age', '3600')
        self.end_headers()

def run(server_class=HTTPServer, handler_class=SimpleRequestHandler, port=8000):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f"Serving on port {port}...")
    httpd.serve_forever()

if __name__ == "__main__":
    run()
